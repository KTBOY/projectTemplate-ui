# 基于 Vue 长列表虚拟滚动实现 virtual-block

####在线体验地址

[完整体验地址](http://shuiniuer.cn/)

注意：该程序仅用于技术分享交流使用，暂不支持商业使用。建议使用移动端设备，以获取最佳体验。

####项目启动方式

```js
//通过当前gitHub地址下载源码后，运行下面命令，安装相关依赖包
npm install
```

```js
//开发环境运行，自动编译和热重载
npm run serve
```

```js
//生产环境运行，自动编译和压缩后输出
npm run build
```

更多自定义配置请前往官方文档： [配置参考  Configuration Reference](https://cli.vuejs.org/config/).

####项目操作简介