import img0 from "../assets/news/0.webp";
import img1 from "../assets/news/1.webp";
import img2 from "../assets/news/2.webp";
import img3 from "../assets/news/3.webp";
import img4 from "../assets/news/4.webp";
import img5 from "../assets/news/5.webp";
import img6 from "../assets/news/6.webp";
import img7 from "../assets/news/7.webp";
import img8 from "../assets/news/8.webp";
import img9 from "../assets/news/9.webp";
import img10 from "../assets/news/10.webp";
import img11 from "../assets/news/11.webp";
import img12 from "../assets/news/12.webp";
import img13 from "../assets/news/13.webp";
import img14 from "../assets/news/14.webp";
import img15 from "../assets/news/15.webp";

let imgsList = [
  img0,
  img1,
  img2,
  img3,
  img4,
  img5,
  img6,
  img7,
  img8,
  img9,
  img10,
  img11,
  img12,
  img13,
  img14,
  img15,
];
export default imgsList;
